from django.shortcuts import render
from django.http import HttpResponse
from CMS_app.models import Bolg_contents,Webpage
from . import forms
from CMS_app.forms import NewuserForm
# Create your views here.


def index(request):
    webpage=Webpage.objects.order_by('Topic')
    web_dict={'Topic_key':webpage}
    return render(request,'CMS_app/index.html',context=web_dict)

def form_view(request):
    form=forms.Form_Name()
    if request.method =='POST':
        form=forms.Form_Name(request.POST)
        if form.is_valid():
            print('Validation Success')
            print('Name : '+form.cleaned_data['name'])
            print('Email : '+form.cleaned_data['Email'])
            print('text : '+form.cleaned_data['text'])
    return render(request,'CMS_app/formpage.html',{'form':form})


def User(request):
    form_user = NewuserForm()
    if request.method == "POST":
        form_user=NewuserForm(request.POST)

        if form_user.is_valid():
            form_user.save(commit=True)

            return render(request,'CMS_app/signup.html',{'form_user':form_user})
        else:
            print("Invalid Data")
        return index(request)
