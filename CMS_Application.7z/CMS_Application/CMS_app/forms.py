from django import forms
from CMS_app.models import Bolg_contents,Webpage,User_blog
from django.core import validators



class Form_Name(forms.Form):
    name=forms.CharField()
    Email=forms.EmailField()
    verify_email=forms.EmailField(label='re enter the email')
    text=forms.CharField(widget=forms.Textarea)



    def clean(self):
        all_clean_data=super().clean()
        email=all_clean_data['Email']
        vemail=all_clean_data['verify_email']
        if email != vemail:
            raise forms.ValidationError("email mismatch")
        else:
            print('Success')

class NewuserForm(forms.ModelForm):
    class Meta:
        model=User_blog
        fields='__all__'
