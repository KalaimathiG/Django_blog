from django.apps import AppConfig


class CmsAppConfig(AppConfig):
    name = 'CMS_app'
