from django.contrib import admin
from CMS_app.models import Bolg_contents,Webpage
# Register your models here.

admin.site.register(Bolg_contents)
admin.site.register(Webpage)
