import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','CMS_Application.settings')

import django
django.setup()

import random
from CMS_app.models import Bolg_contents,Webpage
from faker import Faker

fakegen=Faker()
topics=['Linear Regression','Logistic Regression','XGBoost']

def add_topic():
    t=Bolg_contents.objects.get_or_create(Topic_name=random.choice(topics))[0]
    t.save()
    return t

def populate(N=5):
    for entry in range(N):
        top=add_topic()
        fake_url=fakegen.url()
        fake_name=fakegen.company()
        webpg=Webpage.objects.get_or_create(Topic=top,Name=fake_name,url=fake_url)

if __name__=='__main__':
    print('populaing')
    populate(7)
    print('populating completed')
